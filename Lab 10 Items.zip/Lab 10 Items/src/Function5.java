
public class Function5 extends Function {

	/*
	 * Wavelength of sin function becomes shorter and shorter as x approaches 0,
	 * leading to the behavior we see here
	 */
	@Override
	   public double fnValue(double x)
	   {
	       return Math.sin(1 / x);
	   }
	   public String toString() {
	       return "sin(1/x)";
	   }
}
